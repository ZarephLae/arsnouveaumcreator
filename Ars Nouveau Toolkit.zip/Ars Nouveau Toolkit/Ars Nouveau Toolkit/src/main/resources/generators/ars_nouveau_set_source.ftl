new Object() {
    public void setSourceValue(net.minecraft.world.level.LevelAccessor world, net.minecraft.core.BlockPos pos, int level) {
        if (!world.isClientSide() && world.getBlockEntity(pos) instanceof com.hollingsworth.arsnouveau.api.source.SourceJarBlockEntity jar) {
            // Safe clamp to ensure we don't exceed the jar's natural boundaries
            int max = jar.getMaxSource();
            jar.setSource(Math.max(0, Math.min(level, max)));
        }
    }
}.setSourceValue(${world}, net.minecraft.core.BlockPos.containing(${input$X}, ${input$Y}, ${input$Z}), (int) ${input$LEVEL});