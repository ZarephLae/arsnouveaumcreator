((new Object() {
    public boolean isJarFull(net.minecraft.world.level.LevelAccessor world, net.minecraft.core.BlockPos pos) {
        if (world.getBlockEntity(pos) instanceof com.hollingsworth.arsnouveau.api.source.SourceJarBlockEntity jar) {
            return jar.getSource() >= jar.getMaxSource();
        }
        return false;
    }
}).isJarFull(${world}, net.minecraft.core.BlockPos.containing(${input$X}, ${input$Y}, ${input$Z})))