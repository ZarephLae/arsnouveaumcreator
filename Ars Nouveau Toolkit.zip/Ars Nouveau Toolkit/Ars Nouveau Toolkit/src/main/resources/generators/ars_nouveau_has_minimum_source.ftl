((new Object() {
    public boolean hasMinimumSource(net.minecraft.world.level.LevelAccessor world, net.minecraft.core.BlockPos pos, int min) {
        if (world.getBlockEntity(pos) instanceof com.hollingsworth.arsnouveau.api.source.SourceJarBlockEntity jar) {
            return jar.getSource() >= min;
        }
        return false;
    }
}).hasMinimumSource(${world}, net.minecraft.core.BlockPos.containing(${input$X}, ${input$Y}, ${input$Z}), (int) ${input$MIN}))