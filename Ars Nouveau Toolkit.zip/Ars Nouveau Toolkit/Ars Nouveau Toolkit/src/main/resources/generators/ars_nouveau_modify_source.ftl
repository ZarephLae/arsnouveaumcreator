new Object() {
    public void modifySourceValue(net.minecraft.world.level.LevelAccessor world, net.minecraft.core.BlockPos pos, int amount) {
        if (!world.isClientSide() && world.getBlockEntity(pos) instanceof com.hollingsworth.arsnouveau.api.source.SourceJarBlockEntity jar) {
            if (amount > 0) {
                jar.addSource(amount);
            } else {
                jar.takeSource(Math.abs(amount));
            }
        }
    }
}.modifySourceValue(${world}, net.minecraft.core.BlockPos.containing(${input$X}, ${input$Y}, ${input$Z}), (int) ${input$AMOUNT});