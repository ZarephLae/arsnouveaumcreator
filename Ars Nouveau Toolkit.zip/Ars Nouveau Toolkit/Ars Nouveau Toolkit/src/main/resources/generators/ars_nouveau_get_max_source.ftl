((new Object() {
    public int getMaxSourceValue(net.minecraft.world.level.LevelAccessor world, net.minecraft.core.BlockPos pos) {
        if (world.getBlockEntity(pos) instanceof com.hollingsworth.arsnouveau.api.source.SourceJarBlockEntity jar) {
            return jar.getMaxSource();
        }
        return 0;
    }
}).getMaxSourceValue(${world}, net.minecraft.core.BlockPos.containing(${input$X}, ${input$Y}, ${input$Z})))