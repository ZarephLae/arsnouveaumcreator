((new Object() {
    public int getSourceValue(net.minecraft.world.level.LevelAccessor world, net.minecraft.core.BlockPos pos) {
        if (world.getBlockEntity(pos) instanceof com.hollingsworth.arsnouveau.api.source.SourceJarBlockEntity jar) {
            return jar.getSource();
        }
        return 0;
    }
}).getSourceValue(${world}, net.minecraft.core.BlockPos.containing(${input$X}, ${input$Y}, ${input$Z})))