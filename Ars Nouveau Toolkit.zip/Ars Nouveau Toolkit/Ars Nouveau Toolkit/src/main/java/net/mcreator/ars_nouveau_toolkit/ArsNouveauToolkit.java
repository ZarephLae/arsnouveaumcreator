package net.mcreator.ars_nouveau_toolkit;

import net.mcreator.plugin.JavaPlugin;
import net.mcreator.plugin.Plugin;
import net.mcreator.plugin.events.PreInitializationEvent;
import net.mcreator.blockly.BlocklyBlockLoader;
import net.mcreator.ui.init.L10N;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ArsNouveauToolkit extends JavaPlugin {

    private static final Logger LOG = LogManager.getLogger("ArsNouveauToolkit");

    public ArsNouveauToolkit(Plugin plugin) {
        super(plugin);

        addListener(PreInitializationEvent.class, event -> {
            L10N.loadPluginLocalization(this.getPlugin());

            // Loads the visual block layouts from your resources folder
            BlocklyBlockLoader.INSTANCE.addBlockLoader(stream -> 
                ArsNouveauToolkitPlugin.class.getResourceAsStream("/definitions/ars_nouveau_source.json")
            );

            LOG.info("Successfully registered Ars Nouveau Toolkit procedure blocks.");
        });

        LOG.info("Ars Nouveau Toolkit Plugin initialized!");
    }
}